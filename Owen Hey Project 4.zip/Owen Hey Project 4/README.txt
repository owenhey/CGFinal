Owen Hey Project 4 | 661729120 | Computer Graphics | Professor Ameres

This is a terrain generator that the user can fly around in. You can use the mouse
to look around, press W to speed up, and press S to slow down. If you wish to
change the settings, press "escape".

There is very little actual code in main.cpp. Basically, based on a given "patch size",
it calculates which patch the user is currently over. That then calls the shader program
to create a patch below the player (in high detail), and many less detailed patches surrounding
the player in a 5x5 grid. This (along with fog) creates the illusion of a never-ending terrain.

There are no vertices actually passed into the vertex shader (you can see it is completely empty).
The tesselation control shader creates lots of vertices, and the evaluation shader 
alters their y position with layered perlin noise to create a landscape. Vertex
normals are created by sampling nearby points to create two tangent vectors, then
taking their cross product.

The water is done in the geometry shader, done in two passes so that the transparency works.
First, all the terrain is drawn. Then, the entire thing is ran again but only drawing the
triangles that are underneath the water level. These triangles have their y value moved
up to the water level, and then a sin wave applied to them. This creates a nice water
line. I wish I could figure out a way to not run the program twice (it does all the
perlin noise calculations twice), but since the gpu is so fast it didn't even really
affect anything. However, it was actually necessary to do this to get transparency
in the water (you can see the terrain through the water if you look carefully). 
Otherwise the draw calls aren't in the correct order.

Finally, the frag shader colors the pixels based on some pre-set cutoff values. Water
has a simple specular effect to have some shimmer.

This project didn't end up exactly how I imagined it would when I started (I wanted
to do grass originally), but I am very happy with how much it taught me about
tesselation and geometry shaders. I also am very happy with how the water turned
out.

Thanks for teaching this class! - Owen